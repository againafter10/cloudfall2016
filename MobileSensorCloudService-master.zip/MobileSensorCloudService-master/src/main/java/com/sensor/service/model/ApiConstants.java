package com.sensor.service.model;

/**
 * Created by sindhya on 11/28/16.
 */
public class ApiConstants {

    public static final String path="/Users/nandhu/IdeaProjects/SensorService/src/main/resources/credentials";
    public static final String profile="default";


}

